<?php $__env->startSection('content'); ?>
<div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Listado de Pacientes</h5>
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                    	<th>#</th>
                                    	<th>Nombre del paciente</th>
                                    	<th>Correo</th>
                                    	<th>Teléfono<th>
                                    	<th>Ver datos</th>
                                    	<th>Eliminar</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                    <tr>
                                        <td><?php echo e($patient->id); ?></td>
                                        <td><?php echo e($patient->nombre); ?></td>
                                        <td><?php echo e($patient->correo); ?></td>
                                        <td><?php echo e($patient->telefono); ?></td>
                                        <td>	</td>
                                        <td><a href="/pacientes_edit/<?php echo e($patient->id); ?>/<?php echo e($id); ?>"><i class="fa fa-edit"></i></a></td>
                                        <td><a href="/pacientes_destroy/<?php echo e($patient->id); ?>/<?php echo e($id); ?>"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            </div>
                        </div>
                        <a href="/pacientes_add/<?php echo e($id); ?>" class="btn btn-w-m btn-info">Agregar Paciente</a>
                    </div>
                </div>

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>