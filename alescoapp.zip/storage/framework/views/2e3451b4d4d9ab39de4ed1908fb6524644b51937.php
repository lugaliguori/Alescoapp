<?php $__env->startSection('content'); ?>
<div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Listado de especialidades de los doctores</h5>
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                    	<th>Nombre especialidad</th>
                                        <th>Editar</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                    <tr>
                                        <td><?php echo e($especialidad->nombre); ?></td>
                                        <td><a href="/especialidades_edit/<?php echo e($especialidad->id); ?>/<?php echo e($id); ?>"><i class="fa fa-edit"></i></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            </div>
                        </div>
                        <a href="/especialidad_add/<?php echo e($id); ?>" class="btn btn-w-m btn-info">Agregar Especialidad</a>
                    </div>
                </div>

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>