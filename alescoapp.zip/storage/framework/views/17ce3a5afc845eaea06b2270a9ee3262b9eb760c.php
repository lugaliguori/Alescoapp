<?php $__env->startSection('content'); ?>
  <div class="row">
                <div class="col-lg-8" style="margin: auto">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Programa tu cita</small></h5>
  
                        </div>
                        <div class="ibox-content">
                            <form method="post" name="form-patient" onSubmit="return add_cita()" action="/api/cita-confirm/<?php echo e($id); ?>" novalidate>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Nombre</label>

                                    <div class="col-sm-9"><input type="text" name="name" class="form-control" value="<?php echo e($patient[0]->nombre); ?>" disabled></div>
                                    <div class="col-sm-10"><input type="text" name="id_paciente" class="form-control" value="<?php echo e($patient[0]->id); ?>" hidden></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Fecha de la cita</label>
                                     <div class="col-sm-9"><input type="text" name="fecha" id="fecha" class="form-control" required></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row"><label class="col-sm-3 col-form-label">Doctor</label>
                                      <div class="col-sm-9">
                                        <div class="input-group">
                                          <select class="form-control" name="id_doctor" id="id_doctor" required>
                                              <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($doctor->id); ?>"><?php echo e($doctor->nombre); ?>, <?php echo e($doctor->especialidad); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                          <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button" onClick="toggleSearch()"><i class="fa fa-search"></i></button>
                                          </div>
                                        </div>
                                      <input type="text" class="form-control" id="search" style = "margin-top: 5px; display: none" >        
                                 </div>
                                </div> 
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row"><label class="col-sm-3 col-form-label">Motivo de la cita</label>

                                    <div class="col-sm-9"><label>
                                        <input type="radio" name="motivo" value="Consulta" required> Consulta </label> <label>
                                        <input type="radio" name="motivo" value="Cirugia"> Cirugía </label></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a class="btn btn-white btn-sm" href="/index/<?php echo e($id); ?>">Cancelar</a>
                                        <button class="btn btn-primary btn-sm" type="submit">Siguiente</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php if(isset($cupos)): ?>
                <script>
                $(function() {
                $("#myModal").modal();//if you want you can have a timeout to hide the window after x seconds
                });
                </script>
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Revisa los datos de la cita</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                            <div class="ibox-content" style="border-style: none none none">
                                 <?php if(isset($mensaje)): ?>
                                      <div class="alert alert-danger" role="alert">
                                      <?php echo e($mensaje); ?>

                                      </div>
                                  <?php endif; ?>
                            </div>
                             <form method="post" name="form-patient" id="form" onSubmit="return add_cita()" action="/api/citas" novalidate>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Cupos disponibles</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($cupos); ?>" class="form-control" disabled></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <input name="id_paciente" value="<?php echo e($info->id_paciente); ?>" hidden>
                                <input name="motivo" value="<?php echo e($info->motivo); ?>" hidden>
                                <input name="fecha" value="<?php echo e($info->fecha); ?>" hidden>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Nombre del doctor</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($doctor->nombre); ?>" class="form-control" disabled></div>
                                    <input name="id_doctor" value="<?php echo e($info->id_doctor); ?>" hidden>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Fecha de la cita</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($info->fecha); ?>" name="fecha" class="form-control" disabled></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Hora de la cita</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($doctor->horario); ?>" name="hora" class="form-control"disabled></div>
                                    <div class="col-sm-9"><input type="time" value="<?php echo e($doctor->horario); ?>" name="hora" class="form-control"hidden ></div>
                                </div>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                  <?php if(($cupos >= 1) AND (empty($mensaje))): ?>
                                  <button type="button" onClick="form_submit()" class="btn btn-primary">Guardar Cita</button>
                                  <?php elseif($cupos == 0): ?>
                                  <button type="button" class="btn btn-primary" disabled>Guardar Cita</button>
                                  <?php endif; ?>
                                </form>    
                      </div>               
                    </div>
                  </div>
                </div>
                <?php endif; ?>
                <!--date picker jquery -->
                <script>
                  $( function() {
                    $( "#fecha" ).datepicker({ minDate: new Date(), changeMonth: true,changeYear: true});
                  } );
                  </script>
                   <script type="text/javascript">
                    function form_submit() {
                      document.getElementById("form").submit();
                     }    
                    </script>
              <!--toogle the search field -->
              <script>
                function toggleSearch() {
                  var x = document.getElementById("search");
                  if (x.style.display === "none") {
                    x.style.display = "block";
                  } else {
                    x.style.display = "none";
                  }
                }
              </script>
              <!--filters select list -->
              <script>   
                  jQuery.fn.filterByText = function(textbox, selectSingleMatch) {
                      return this.each(function() {
                          var select = this;
                          var options = [];
                          $(select).find('option').each(function() {
                              options.push({value: $(this).val(), text: $(this).text()});
                          });
                          $(select).data('options', options);
                          $(textbox).bind('change keyup', function() {
                              var options = $(select).empty().data('options');
                              var search = $(this).val().trim();
                              var regex = new RegExp(search,"gi");
                            
                              $.each(options, function(i) {
                                  var option = options[i];
                                  if(option.text.match(regex) !== null) {
                                      $(select).append(
                                         $('<option>').text(option.text).val(option.value)
                                      );
                                  }
                              });
                              if (selectSingleMatch === true && $(select).children().length === 1) {
                                  $(select).children().get(0).selected = true;
                              }
                          });            
                      });
                  };

                  $(function() {
                      $('#id_doctor').filterByText($('#search'), true);
                    });  
              </script>  


  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>