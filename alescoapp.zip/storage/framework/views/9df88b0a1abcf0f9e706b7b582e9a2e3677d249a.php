<nav class="navbar fixed-bottom navbar-light bg-light">
  <span>Aplicación desarrollada por Corporación JSK para Alesco. Todos los derechos reservados.</span>
</nav>