<?php $__env->startSection('content'); ?>
  <div class="row">
                <div class="col-lg-8" style="margin: auto">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Confirma tu cita</small></h5>
  
                        </div>
                        <div class="ibox-content">
                             <?php if(isset($mensaje)): ?>
                                  <div class="alert alert-primary" role="alert">
                                  <?php echo e($mensaje); ?>

                                  </div>
                              <?php endif; ?>
                            <div class="row justify-content-end">
                                <div class="col-sm-3">
                                    <form method="POST" action="/api/cita-confirm/<?php echo e($id); ?>">
                                    <div class="input-group"><input placeholder="<?php echo e($info->fecha); ?>" type="text" name="fecha" id="fecha" class="form-control form-control-sm">
                                    <input name="id_paciente" value="<?php echo e($info->id_paciente); ?>" hidden>
                                    <input name="id_doctor" value="<?php echo e($info->id_doctor); ?>" hidden>
                                    <input name="admin" value="<?php echo e($info->admin); ?>" hidden>
                                     <span class="input-group-append"> 
                                    <button type="submit" class="btn btn-sm btn-primary">Ir</button> </span></div>
                                </form>
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <?php if($cupos >= 1): ?>
                            <form method="post" name="form-patient" onSubmit="return add_cita()" action="/api/citas" novalidate>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Cupos disponibles</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($cupos); ?>" class="form-control" disabled></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <input name="id_paciente" value="<?php echo e($info->id_paciente); ?>" hidden>
                                <input name="admin" value="<?php echo e($info->admin); ?>" hidden>
                                <input name="motivo" value="<?php echo e($info->motivo); ?>" hidden>
                                <input name="fecha" value="<?php echo e($info->fecha); ?>" hidden>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Nombre del doctor</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($doctor->nombre); ?>" class="form-control" disabled></div>
                                    <input name="id_doctor" value="<?php echo e($info->id_doctor); ?>" hidden>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Fecha de la cita</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($info->fecha); ?>" name="fecha" class="form-control" disabled></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Hora de la cita</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($doctor->horario); ?>" name="hora" class="form-control"></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a class="btn btn-white btn-sm" href="/admin/<?php echo e($id); ?>">Cancelar</a>
                                        <button class="btn btn-primary btn-sm" type="submit">Crear cita</button>
                                    </div>
                                </div>
                            </form>
                            <?php elseif($cupos == 0): ?>
                                     <form method="post" name="form-patient" onSubmit="return add_cita()" action="/api/citas" novalidate>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Cupos disponibles</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($cupos); ?>" class="form-control" disabled></div>
                                </div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Cupos disponibles</label>
                                    <div class="col-sm-9"><span>No quedan cupos disponibles para el doctor <?php echo e($doctor->nombre); ?> en la fecha indicada, prueba otra fecha</span></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a class="btn btn-white btn-sm" href="/admin/<?php echo e($id); ?>">Cancelar</a>
                                        <button class="btn btn-primary btn-sm" type="submit" disabled>Crear cita</button>
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <script>
                  $( function() {
                    $( "#fecha" ).datepicker({ minDate: new Date(), changeMonth: true,changeYear: true});
                  } );
                  </script>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>