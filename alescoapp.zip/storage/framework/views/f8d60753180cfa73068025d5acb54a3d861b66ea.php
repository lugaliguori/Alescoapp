<!DOCTYPE html>
 
<html lang="en">
 
 <head>
 
   <?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 	
 </head>
 
 <body>
 	

			<?php $__env->startSection('sidebar'); ?>
	  			<?php echo $__env->make('layouts.partials.nav-admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	  		<?php echo $__env->yieldSection(); ?>

		  	<?php echo $__env->yieldContent('content'); ?>



 </body>
  <footer>
 	<?php $__env->startSection('footer'); ?>
 		<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 	<?php echo $__env->yieldSection(); ?>
 </footer>	

</html>