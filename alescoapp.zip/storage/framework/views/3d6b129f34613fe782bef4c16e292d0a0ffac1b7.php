<!DOCTYPE html>
 
<html lang="en">
 
 <head>
 
   <?php echo $__env->make('layouts.partials.login-head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 	
 </head>
 
 <body class="gray-bg">

	  <div id="main"">
	  		<?php echo $__env->yieldContent('content'); ?>
	  </div>


 </body>
 
<footer>
 	<?php $__env->startSection('footer'); ?>
 		<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 	<?php echo $__env->yieldSection(); ?>
 </footer>	
 
</html>