<?php $__env->startSection('content'); ?>
  <div class="row">
                <div class="col-lg-8" style="margin: auto">
                   <?php if(isset($message)): ?>
                      <div class="alert alert-primary" role="alert">
                      <?php echo e($message); ?>

                  </div>
                  <?php endif; ?>
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Editar datos del doctor</small></h5>
  
                        </div>
                        <div class="ibox-content">
                            <form method="post" name="form-patient" action="/api/doctors/<?php echo e($info[0]->id); ?>" novalidate>
                              <?php echo method_field('PUT'); ?>
                              <?php echo csrf_field(); ?>
                                <div class="form-group  row"><label class="col-sm-2 col-form-label">Nombre</label>

                                    <div class="col-sm-10"><input class="form-control" value="<?php echo e($info[0]->nombre); ?>" name="nombre" id="nombre" required></div>
                                    <input class="text" id="id" name="id" value="<?php echo e($id); ?>" hidden>

                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-2 col-form-label">Apellido</label>

                                    <div class="col-sm-10"><input class="form-control" name="apellido" id="apellido" value="<?php echo e($info[0]->apellido); ?>" required></div>

                                </div>
                                <div class="hr-line-dashed"></div>

                                <div class="form-group  row"><label class="col-sm-2 col-form-label">Cédula</label>
                                <div class="col-sm-10"><input type="text" name="cedula" id="cedula" class="form-control" value="<?php echo e($info[0]->cedula); ?>" required></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-2 col-form-label">Correo</label>
                                     <div class="col-sm-10"><input type="email" value="<?php echo e($info[0]->correo); ?>" name="correo" id="correo" class="form-control" required></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row"><label class="col-sm-2 col-form-label">Password</label>

                                    <div class="col-sm-10"><input type="password" value="<?php echo e($info[0]->password); ?>" class="form-control" name="password" id="password"required></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row"><label class="col-sm-2 col-form-label">Especialidad</label>
                                    <div class="col-sm-10"><select class="form-control" name="id_especialidad" id="id_especialidad" required>
                                        <?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <linea>
                                          <option value="<?php echo e($especialidad->id); ?>"><?php echo e($especialidad->nombre); ?></option>
                                        </linea>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>  
                                    </div>    
                                 </div>
                                 <div class="hr-line-dashed"></div>
                                <div class="form-group row"><label class="col-sm-2 col-form-label">Hora de inicio de citas</label>
                                        <div class="col-sm-10"><input type="text" class="form-control" value="<?php echo e($info[0]->horario); ?>" name="horario" id="horario" required></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <?php if($administrador == 1): ?>
                                 <div class="form-group row"><label class="col-sm-2 col-form-label">Administrador</label>
                                    <div class="col-sm-10"><label>
                                        <input type="radio" name="admin" id="admin" value="1"> Si </label>
                                    </div>
                                </div> 
                                <div class="hr-line-dashed"></div>
                                <?php endif; ?>
                                <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a class="btn btn-white btn-sm" href="/doctores/<?php echo e($id); ?>">Cancelar</a>
                                        <button class="btn btn-primary btn-sm" type="submit">Actualizar Datos</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
           </div>
           <script>
           $(document).ready(function(){
                 $('#horario').timepicker({});
            });
           </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>