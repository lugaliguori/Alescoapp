Buenos dias! <?php echo e($nombre_paciente); ?>

El oncologico luis razetti se complace en anunciar la conformacion de su cita.
 
Para el dia: <?php echo e($fecha); ?>, con el doctor <?php echo e($nombre_doctor); ?>. A partir de las <?php echo e($hora); ?>

 
Recuerde que si desea cancelar su cita puede hacerlo desde la pagina.

