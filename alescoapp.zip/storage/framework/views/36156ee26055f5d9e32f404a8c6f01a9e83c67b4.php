<?php $__env->startSection('content'); ?>
  <div class="row">
                <div class="col-lg-8" style="margin: auto">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Programa tu cita</small></h5>
  
                        </div>
                        <div class="ibox-content">
                            <form method="post" name="form-patient" onSubmit="return add_cita()" action="/api/cita-confirm/<?php echo e($id); ?>" novalidate>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Nombre</label>

                                    <div class="col-sm-9">
                                      <div class="input-group">
                                        <select class="form-control" name="id_paciente" id="id_paciente" required></div>
                                          <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <linea>
                                            <option value="<?php echo e($patient->id); ?>"><?php echo e($patient->nombre); ?></option>
                                          </linea>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                          <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button" onClick="toggleSearchPatient()"><i class="fa fa-search"></i></button>
                                          </div>     
                                      </div> 
                                      <input type="text" class="form-control" id="search_patient" style = "margin-top: 5px; display: none" >     
                                 </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Fecha de la cita</label>
                                     <div class="col-sm-9"><input type="text" name="fecha" id="fecha" class="form-control" required></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <?php if($administrador == 1): ?>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Nombre</label>
                                    <div class="col-sm-9">
                                      <div class="input-group">
                                        <select class="form-control" name="id_doctor" id="id_doctor" required>
                                          <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <linea>
                                            <option value="<?php echo e($doc->id); ?>"><?php echo e($doc->nombre); ?> <?php echo e($doc->apellido); ?>, <?php echo e($doc->especialidad); ?></option>
                                          </linea>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>  
                                          <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="button" onClick="toggleSearchDoctor()"><i class="fa fa-search"></i></button>
                                          </div>  
                                      </div>
                                      <input type="text" class="form-control" id="search_doctor" style = "margin-top: 5px; display: none" >          
                                  </div>
                                 </div> 

                                <?php else: ?>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Nombre del Doctor</label>

                                    <div class="col-sm-9"><input type="text" name="name" class="form-control" value="<?php echo e($doctor->nombre); ?> <?php echo e($doctor->apellido); ?>, <?php echo e($doctor->especialidad); ?>" disabled></div>
                                    <div class="col-sm-10"><input type="text" name="id_doctor" class="form-control" value="<?php echo e($doctor->id); ?>" hidden></div>
                                </div>
                                <?php endif; ?> 
                                <input name="admin" value="<?php echo e($administrador); ?>" hidden>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row"><label class="col-sm-3 col-form-label">Motivo de la cita</label>

                                    <div class="col-sm-9"><label>
                                        <input type="radio" name="motivo" value="Consulta" required> Consulta </label> <label>
                                        <input type="radio" name="motivo" value="Cirugía"> Cirugía </label></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a class="btn btn-white btn-sm" href="/index/<?php echo e($id); ?>">Cancelar</a>
                                        <button class="btn btn-primary btn-sm" type="submit">Siguiente</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php if(isset($cupos)): ?>
                <script>
                $(function() {
                $("#myModal").modal();//if you want you can have a timeout to hide the window after x seconds
                });
                </script>
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Revisa los datos de la cita</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                            <div class="ibox-content" style="border-style: none none none">
                                 <?php if(isset($mensaje)): ?>
                                      <div class="alert alert-danger" role="alert">
                                      <?php echo e($mensaje); ?>

                                      </div>
                                  <?php endif; ?>
                            </div>
                             <form method="post" name="form-patient" id="form" onSubmit="return add_cita()" action="/api/citas" novalidate>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Numero en la lista</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($puesto); ?>" class="form-control" disabled></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <input name="id_paciente" value="<?php echo e($info->id_paciente); ?>" hidden>
                                <input name="admin" value="<?php echo e($info->admin); ?>" hidden>
                                <input name="motivo" value="<?php echo e($info->motivo); ?>" hidden>
                                <input name="fecha" value="<?php echo e($info->fecha); ?>" hidden>
                                <input name="id_user" value="<?php echo e($id); ?>" hidden>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Nombre del doctor</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($doctor->nombre); ?>" class="form-control" disabled></div>
                                    <input name="id_doctor" value="<?php echo e($info->id_doctor); ?>" hidden>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Fecha de la cita</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($info->fecha); ?>" name="fecha" class="form-control" disabled></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group  row"><label class="col-sm-3 col-form-label">Hora de la cita</label>
                                    <div class="col-sm-9"><input type="text" value="<?php echo e($doctor->horario); ?>" name="hora" class="form-control"></div>
                                </div>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                 <?php if(($cupos >= 1) AND (empty($mensaje))): ?>
                                  <button type="button" onClick="form_submit()" class="btn btn-primary">Guardar Cita</button>
                                  <?php elseif($cupos == 0): ?>
                                  <button type="button" class="btn btn-primary" disabled>Guardar Cita</button>
                                  <?php endif; ?>
                                </form>    
                      </div>               
                    </div>
                  </div>
                </div>
                <?php endif; ?>
                <script>
                  $( function() {
                    $( "#fecha" ).datepicker({ minDate: new Date(), changeMonth: true,changeYear: true});
                  } );
                  </script>
                   <script type="text/javascript">
                    function form_submit() {
                      document.getElementById("form").submit();
                     }    
                    </script>
                    <script>
                      function toggleSearchPatient() {
                        var x = document.getElementById("search_patient");
                        if (x.style.display === "none") {
                          x.style.display = "block";
                        } else {
                          x.style.display = "none";
                        }
                      }
                    </script>
                    <script>
                      function toggleSearchDoctor() {
                        var x = document.getElementById("search_doctor");
                        if (x.style.display === "none") {
                          x.style.display = "block";
                        } else {
                          x.style.display = "none";
                        }
                      }
                    </script>
                    <script>   
                  jQuery.fn.filterByText = function(textbox, selectSingleMatch) {
                      return this.each(function() {
                          var select = this;
                          var options = [];
                          $(select).find('option').each(function() {
                              options.push({value: $(this).val(), text: $(this).text()});
                          });
                          $(select).data('options', options);
                          $(textbox).bind('change keyup', function() {
                              var options = $(select).empty().data('options');
                              var search = $(this).val().trim();
                              var regex = new RegExp(search,"gi");
                            
                              $.each(options, function(i) {
                                  var option = options[i];
                                  if(option.text.match(regex) !== null) {
                                      $(select).append(
                                         $('<option>').text(option.text).val(option.value)
                                      );
                                  }
                              });
                              if (selectSingleMatch === true && $(select).children().length === 1) {
                                  $(select).children().get(0).selected = true;
                              }
                          });            
                      });
                  };

                  $(function() {
                      $('#id_doctor').filterByText($('#search_doctor'), true);
                    });
                    $(function() {
                      $('#id_paciente').filterByText($('#search_patient'), true);
                    });    
              </script>  
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>