<?php $__env->startSection('content'); ?>
<div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>Tus Citas </h5>
                        </div>
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                    	<th>Nombre del paciente</th>
                                    	<th>Fecha</th>
                                    	<th>Nombre doctor</th>
                                    	<th>Motivo</th>
                                    	<th>Cancelar cita</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                    <tr>
                                        <td><?php echo e($info->nombre_paciente); ?></td>
                                        <td><?php echo e($info->fecha); ?></td>
                                        <td><?php echo e($info->nombre); ?></td>
                                        <td><?php echo e($info->motivo); ?></td>
                                        <td><a href="/citas_destroy/<?php echo e($info->fecha); ?>/<?php echo e($info->id); ?>/<?php echo e($info->id_doc); ?>"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
          <script>
          $( function() {
            $( "#fecha" ).datepicker({ minDate: new Date()});
          } );
          </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>