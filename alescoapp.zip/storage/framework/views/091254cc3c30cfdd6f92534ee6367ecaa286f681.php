Buenos dias! <?php echo e($nombre_paciente); ?>

<p>El oncologico luis razetti se complace en anunciar la conformacion de su cita.</p>
 
<p><u>Para el dia: <?php echo e($fecha); ?>, con el doctor <?php echo e($nombre_doctor); ?>. A partir de las <?php echo e($hora); ?></u></p>
 
Recuerde que si desea cancelar su cita puede hacerlo desde la pagina.
<br/>
