Buenos dias! {{$nombre_paciente}}
El oncologico luis razetti se complace en anunciar la conformacion de su cita.
 
Para el dia: {{$fecha}}, con el doctor {{$nombre_doctor}}. A partir de las {{$hora}}
 
Recuerde que si desea cancelar su cita puede hacerlo desde la pagina.

