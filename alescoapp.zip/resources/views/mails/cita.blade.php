Buenos dias! {{$nombre_paciente}}
<p>El oncologico luis razetti se complace en anunciar la conformacion de su cita.</p>
 
<p><u>Para el dia: {{$fecha}}, con el doctor {{$nombre_doctor}}. A partir de las {{$hora}}</u></p>
 
Recuerde que si desea cancelar su cita puede hacerlo desde la pagina.
<br/>
